export type Article = {
    id: string; // Change from number to string
    title: string;
    imageUrl: string;
    content: string;
};
